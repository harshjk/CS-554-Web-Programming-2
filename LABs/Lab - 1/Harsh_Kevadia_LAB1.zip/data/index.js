/******************************************
 *  Author : Harsh Jagdishbhai Kevadia   
 *  Created On : Wed Sep 13 2017
 *  File : index.js
 *******************************************/
const taskData = require("./tasks");

module.exports = {
    tasks: taskData
};